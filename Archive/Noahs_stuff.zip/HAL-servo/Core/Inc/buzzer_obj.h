#ifndef BUZZER_OBJ_H
#define BUZZER_OBJ_H

#include <stdlib.h>
#include <math.h>




#endif
